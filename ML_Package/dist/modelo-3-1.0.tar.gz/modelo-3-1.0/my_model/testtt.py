import pandas as pd
from config.core import config
from processing.data_manager import load_dataset
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.metrics import (accuracy_score, classification_report,
                             confusion_matrix, plot_roc_curve, roc_auc_score)
from sklearn.model_selection import (GridSearchCV, cross_val_score,
                                     train_test_split)
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, MinMaxScaler, StandardScaler
from sklearn.svm import SVC

data = pd.read_csv('/datesets/winee.csv')
X_train, X_test, Y_train, Y_test = train_test_split(
        data[config.model_config.features],
        data[config.model_config.target],
        test_size=config.model_config.test_size,
        # we are setting the random seed here
        # for reproducibility
        random_state=config.model_config.random_state,
    )
 
X_train = pd.DataFrame(X_train, columns=["alcohol", "fixed acidity", "volatile acidity", "residual sugar","chlorides", "free sulfur dioxide", "total sulfur dioxide","density", "pH", "sulphates"])
X_test = pd.DataFrame(X_test, columns=["alcohol", "fixed acidity", "volatile acidity", "residual sugar","chlorides", "free sulfur dioxide", "total sulfur dioxide","density", "pH", "sulphates"])
Y_train = pd.DataFrame(Y_train, columns=["quality"])
Y_test = pd.DataFrame(Y_test, columns=["quality"])
train = pd.concat([X_train, Y_train], axis=1, join="inner")

test = pd.concat([X_test, Y_test], axis=1, join="inner")

train.to_csv('.\datasets\train.csv')
test.to_csv('.\datasets\test.csv')